import streamlit as st
import pickle
import pandas as pd


def recommend(book):
    book_index = books[books['title'] == book].index[0]
    distance = similarity[book_index]
    book_list = sorted(list(enumerate(distance)), reverse=True, key=lambda x:x[1])[1:6]

    recommended_books = []
    #recommended_book_poster = []
    for i in book_list:
        #ISBN = books.iloc[i[0]].Image-URL-M
        recommended_books.append(books.iloc[i[0]].title)
        #recommended_book_poster.append(ISBN)

    return recommended_books

books_dict= pickle.load(open('book_d.pkl','rb'))
books= pd.DataFrame(books_dict)

similarity = pickle.load(open('simil.pkl','rb'))


st.title('Book Recommendation System')




Selected_book_name = st.selectbox(
'How would you like to be contacted?',
books['title'].values)

if st.button('Recommend'):
    commendations = recommend(Selected_book_name)
    for i in commendations:
        st.write(i)