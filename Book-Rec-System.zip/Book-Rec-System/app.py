import streamlit as st
import pickle
import pandas as pd
import requests

def fetch_poster(book_ID):
    response= request.get('https://covers.openlibrary.org/b/isbn/{}-S.jpg'.format(book_ID))
    data = response.json()
    return


def recommend(book):
    book_index = books[books['title'] == book].index[0]
    distance = simi[book_index]
    book_list = sorted(list(enumerate(distance)), reverse=True, key=lambda x: x[1])[1:6]

    recommend_books = []
     recommend_book_poster = []
     for i in book_list:
        book_ID = book
